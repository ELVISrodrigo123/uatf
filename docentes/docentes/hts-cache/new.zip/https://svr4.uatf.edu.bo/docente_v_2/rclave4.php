<!DOCTYPE html>
<html>
<head>
  <title>U.A.T.F. - Docentes</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <style type="text/css">
	/* Sticky footer styles
	-------------------------------------------------- */
	html { position: relative; min-height: 100%; }
	body {
	  /* Margin bottom by footer height */
	  margin-bottom: 60px;
	}
	.footer {
	  position: absolute;
	  bottom: 0;
	  width: 100%;
	  /* Set the fixed height of the footer here */
	  height: 60px;
	  /*background-color: #f5f5f5;*/
	  background-color: rgb(64, 85, 134);
	}
	/* Custom page CSS
	-------------------------------------------------- */
	/* Not required for template or sticky footer method. */

	body > .container {  padding: 60px 15px 0; }
	.container .text-muted { margin: 20px 0; }

	.footer > .container { padding-right: 15px; padding-left: 15px;	}
	
	.ar:link { color: #FFFFFF; }

	/* visited link */
	.ar:visited { color: #FFFFFF; }

	/* mouse over link */
	.ar:hover { color: #DDDDDD; }

	/* selected link */
	.ar:active { color: #FFFFFF; }
  </style>
  <script type="text/javascript">
	    var nav = navigator.appName;
	    // Detectamos si nos visitan desde IE
	    if(nav == "Microsoft Internet Explorer")
	    {
		// Convertimos en minusculas la cadena que devuelve userAgent
		var ie = navigator.userAgent.toLowerCase();
		// Extraemos de la cadena la version de IE
		var version = parseInt(ie.split('msie')[1]);

		// Dependiendo de la version mostramos un resultado
		switch(version)
		{
		    case 6:
		        alert("Estas usando IE 6, es obsoleto actualize su Navegador Web");
			window.location.href = 'http://www.uatf.edu.bo/'; 
		        break;
		    case 7:
		        alert("Estas usando IE 7, es obsoleto actualize de Navegador Web");
			window.location.href = 'http://www.uatf.edu.bo/'; 
		        break;
		    case 8:
		        alert("Estas usando IE 8, es obsoleto actualize de Navegador Web");
			window.location.href = 'http://www.uatf.edu.bo/'; 
		        break;
		    case 9:
		        alert("Estas usando IE 9, mas o menos compatible");
		        break;
		    default:
		        alert("Usas una version compatible");
		        break;
		}
	    }
	    function setfocus()
	    {
		document.forma.usuario.focus();
     	    }	
  </script>
  <link href='imgs/uatf.ico' type='image/x-icon' rel='shortcut icon' />
	<!--[if lte IE 7]>
	<style>
	.content { margin-right: -1px; } /* este margen negativo de 1 px puede situarse en cualquiera de las columnas de este diseño con el mismo efecto corrector. */
	ul.nav a { zoom: 1; }  /* la propiedad de zoom da a IE el desencadenante hasLayout que necesita para corregir el espacio en blanco extra existente entre los vínculos */
	</style>
	<![endif]-->		
</head>
<body onload="setfocus()">

    <nav class="navbar navbar-default navbar-fixed-top" style=" background-color: rgb(64, 85, 134);" class="ar">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php"><span style="color:#FFFFFF;">M&oacute;dulo [Docentes]</span></a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="rclave.php">Inicio</a></li>
            <li><a href="#about"><span style="color:#FFFFFF;">Acerca de..</span></a></li>
            <li><a href="#contact"><span style="color:#FFFFFF;">Contactenos</span></a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

<div class="container">
	<div class="container-fluid">
	  <div class="row">
		<div class="col-sm-12" >
			<div class="progress">
			  <div class="progress-bar progress-bar progress-bar-striped" role="progressbar"
			  aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
			    70% Complete
			  </div>
			</div>

			<table width="100%" border="0">
				<tr>
					<td>
						<h3>Te enviamos un mensaje de texto a al n&uacute;mero de tel&eacute;fono personal registrado con un codigo</h3>
					</td>
				</tr>

			</table>
		</div>
	  </div>
	  <div class="row">
	    <div class="col-sm-6" >
		<p align="Justify">Bienvenido <strong></strong> por favor revise su tel&eacute;fono personal e introduzca el codigo de verificaci&oacute;n que fue enviado.</p>
					<p align="center">
						<img src="imgs/smsu.png"/>
					</p>
					<p>Sistema de Informaci&oacute;n Acad&eacute;mica potenciado con Software Libre.</p>
	    </div>
	    <div class="col-sm-6" >

                <div class="panel panel-default">
                   <div class="panel-body">
					<form style="margin-bottom: 0px !important;" class="form-horizontal" id="forma" name="forma" action="reset.php" method="post" >

						<input type="hidden" id="javas" name="javas" value="N">
						<input type="hidden" id="var1"  name="var1"  value="0">
						<input type="hidden" name="token" id="token" value="e6db606c6e7e9eea7d4e8fce10237e11" />

						<div class="content">
							 <h3 align="center"><i class="fa fa-lock fa-4x"></i>
								
							  </h3>


							  <div class="row panel" style="color:#ffffff;background-color:rgb(64, 85, 134);">
								  <h4 class="text-center">Introduzca codigo de verificaci&oacute;n</h4>
							  </div>
							<h5 class="title" align="center"><em> Paso Nro 3 </em></h5>
							<!--
							<h5 class="title" align="center"><em> Ayuda de N&uacute;mero:  ..........  </em></h5>
							-->
								<div class="form-group">
									<div class="col-sm-12">
										<div class="input-group">
										<span class="input-group-addon"><i class="glyphicon glyphicon-phone color-blue"></i></span>
										<input type="text" size="8" maxlength="8"  id="codigo_per" name="codigo_per" placeholder="Ej: XYZA1234" class="form-control" oninvalid="setCustomValidity('Por favor complete su numero')" onchange="try{setCustomValidity('')}catch(e){}" required="">
										</div>
									</div>
								</div>
							<!--
							<h5 class="title" align="center"><em> Ticket de Seguridad: e6db606c6e7e9eea7d4e8fce10237e11 </em></h5>
							-->
						</div>
						<div align="center">		
						&nbsp;	
						</div>

						<div class="foot" align="center">
							<button class="btn btn-primary" data-dismiss="modal" type="submit">Reiniciar Contraseña</button>
						</div>
						<br/>
				<span align="center">Cualquier duda o sugerencia:&nbsp; 
					<a href="https://www.facebook.com/uti.uatf" target="_blank"><i class="fa fa-facebook-square">Facebook</i></a>
				</span>

					</form>
				</div>
			</div>
	    </div>

	  </div>

	</div>

	
</div>
    <footer class="footer">
      <div class="container">
        	<div class="text-muted out-links">
			<a href="#" class="ar">&copy; 2024 Universidad Aut&oacute;noma Tom&aacute;s Fr&iacute;as - Sistema de Informaci&oacute;n Acad&eacute;mica </a>
		</div>
      </div>
    </footer>

</body>
</html>

